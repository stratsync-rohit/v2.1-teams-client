import { getReactionPresentation } from "@/lib/api/normalization";

export function ReactionSummaryBadges({ counts, emptyLabel = "No reactions", className = "", onClick, ariaLabel = "View reactions" }: { counts?: Record<string, number>; emptyLabel?: string | null; className?: string; onClick?: () => void; ariaLabel?: string }) {
  const reactions = Object.entries(counts ?? {}).filter(([, count]) => Number.isFinite(count) && count > 0);
  if (reactions.length === 0) return emptyLabel ? <span className={`text-xs text-slate-500 ${className}`}>{emptyLabel}</span> : null;
  const content = reactions.map(([reaction, count]) => { const presentation = getReactionPresentation(reaction); const isUnknown = presentation.icon === "🙂"; return <span key={reaction} title={`${presentation.label}: ${count}`} className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-1 text-xs font-medium text-slate-700"><span aria-hidden="true">{presentation.icon}</span>{isUnknown && <span>{presentation.label}</span>}<span>{count}</span></span>; });
  if (onClick) return <button type="button" aria-label={ariaLabel} onClick={onClick} className={`flex flex-wrap gap-1.5 rounded-md text-left hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-600 ${className}`}>{content}</button>;
  return <div className={`flex flex-wrap gap-1.5 ${className}`}>{content}</div>;
}
