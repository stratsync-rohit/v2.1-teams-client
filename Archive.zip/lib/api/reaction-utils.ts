import type { NotificationReaction } from "../types.js";

export function getReactionType(reaction: NotificationReaction): string {
  return reaction.reaction ?? reaction.reaction_type ?? "unknown";
}

export function getActiveReactionCounts(
  reactions: readonly NotificationReaction[],
): Record<string, number> {
  return reactions.reduce<Record<string, number>>((counts, reaction) => {
    if (!reaction.is_active) return counts;
    const type = getReactionType(reaction);
    counts[type] = (counts[type] ?? 0) + 1;
    return counts;
  }, {});
}

export function getReactionUserLabel(reaction: NotificationReaction): string {
  return (
    reaction.user_display_name ??
    reaction.display_name ??
    reaction.user_name ??
    reaction.user_identifier ??
    reaction.user_aad_id ??
    "Unknown user"
  );
}
